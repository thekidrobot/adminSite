scrolldiv_setColor('#999999');	// Setting border color of the scrolling content
setSliderBgColor('#FFFFFF');	// Setting color of the slider div
setContentBgColor('#FFFFFF');	// Setting color of the scrolling content
setScrollButtonSpeed(4);	// Setting speed of scrolling when someone clicks on the arrow or the slider
setScrollTimer(5);	// speed of 1 and timer of 5 is the same as speed of 2 and timer on 10 - what's the difference? 1 and 5 will make the scroll move a little smoother.
scrolldiv_setWidth(712);	// Setting total width of scrolling div
scrolldiv_setHeight(400);	// Setting total height of scrolling div
scrolldiv_initScroll();	// Initialize javascript functions
