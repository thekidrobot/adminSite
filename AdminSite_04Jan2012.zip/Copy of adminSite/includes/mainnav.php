<ul id="mainNav">
	<li><a href="menuadmin.php"><?=_("Live Tv")?></a></li>
	<li><a href="menuadmin.php"><?=_("VOD")?></a></li>
	<li><a href="categoriasVideos.php"><?=_("Categories")?></a></li>
	<li><a href="gruposPaquetes.php"><?=_("Packages")?></a></li>
	<li><a href="admusuarios.php"><?=_("Subscribers")?></a></li>
	<li><a href="#"><?=_("Reports")?></a></li>
	<li><a href="#"><?=_("Support")?></a></li>
	<li><a href="#"><?=_("FAQ")?></a></li>
	<li class="logout"><a href="index.php"><?=_("Logout")?></a></li>
</ul>